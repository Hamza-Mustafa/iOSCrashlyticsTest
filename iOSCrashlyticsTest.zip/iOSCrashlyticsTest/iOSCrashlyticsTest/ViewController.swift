//
//  ViewController.swift
//  iOSCrashlyticsTest
//
//  Created by Hamza Mustafa on 20/04/2021.
//

import UIKit
import FirebaseCrashlytics

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func crashTapped(_ sender: UIButton) {
        fatalError()
    }
    
}

